<?php
/**
 * @author    Labham Vishwakarma
 * @copyright Copyright (c) 2023 Tech9logy (https://www.tech9logy.com/)
 * @package   Tech9logy_Smtp
 */
namespace Tech9logy\Smtp\Controller\Adminhtml\Smtp;

use Laminas\Mail\Transport\Smtp;
use Laminas\Mail\Transport\SmtpOptions;
use Laminas\Mail\Message;
use Laminas\Mime\Message as MessageBody;
use Laminas\Mime\Part;
use Laminas\Mime\Mime;

class TestMail extends \Magento\Backend\App\Action
{
    /**
     * EtatavasoftSmtpHelper
     *
     * @var \Tech9logy\Smtp\Helper\Data
     */
    protected $smtpHelper;

    /**
     * JsonHelper
     *
     * @var \Magento\Framework\Json\Helper\Data
     */
    protected $jsonHelper;

    /**
     * Constructor
     *
     * @param \Magento\Backend\App\Action\Context $context    context
     * @param \Tech9logy\Smtp\Helper\Data         $smtpHelper smtpHelper
     * @param \Magento\Framework\Json\Helper\Data $jsonHelper jsonHelper
     */
    public function __construct(
        \Magento\Backend\App\Action\Context $context,
        \Tech9logy\Smtp\Helper\Data $smtpHelper,
        \Magento\Framework\Json\Helper\Data $jsonHelper
    ) {
        $this->smtpHelper = $smtpHelper;
        $this->jsonHelper = $jsonHelper;
        parent::__construct($context);
    }

    /**
     * TestMail action
     *
     * @return \Magento\Framework\App\ResponseInterface
     */
    public function execute()
    {
        $postParams = $this->getRequest()->getParams();
        $host = $this->smtpHelper->getSmtpHostConfig();
        $port = $this->smtpHelper->getSmtpPortConfig();
        $smtpConf  = [
            'name' => 'localhost',
            'host' => $host,
            'port' => $port
        ];
        $auth = strtolower($this->smtpHelper->getSmtpAuthConfig());
        $username = $this->smtpHelper->getSmtpUsername();
        $password = $this->smtpHelper->getSmtpPassword();

        if ($auth && $auth !== 'none') {
            ($auth == 'cram-md5') ? $auth = 'plain':'';
            $smtpConf['connection_class'] = $auth;
            $smtpConf['connection_config']['username'] = $username;
            $smtpConf['connection_config']['password'] = $password;
        }

        $ssl = $this->smtpHelper->getSmtpSslConfig();

        if ($ssl && $ssl !== 'none') {
            $smtpConf['connection_config']['ssl'] = $ssl;
        }

        $toEmail = $postParams['toEmail'];
        $fromEmail = $postParams['fromEmail'] ? $postParams['fromEmail'] : $username;

        if (!filter_var($toEmail, FILTER_VALIDATE_EMAIL) || (!filter_var($postParams['fromEmail'], FILTER_VALIDATE_EMAIL) && !empty($postParams['fromEmail']))
        ) {
            $result = [
                'success' => 0,
                'message' => 'Please enter valid email address.'
            ];
            return $this->getResponse()->representJson(
                $this->jsonHelper->jsonEncode($result)
            );
        } else {
            $transport = new Smtp();
            $transport->setOptions(new SmtpOptions($smtpConf));
            $message = new Message();
            list($name, $domain) = explode('@', $toEmail);
            $content = "<p>Hello, $name,</p>
            <p><strong>SMTP configurations are done properly.</strong></p>
            <p>Your store has been successfully connected and ready to send emails with SMTP.</p>
            <p>Thank you for using Tech9logy SMTP extension.</p>
            <p><i>This is an e-mail message sent by Tech9logy SMTP extension while testing the settings for your extension.</i></p>";
            $signature = '<div><table cellspacing="0" style="max-width:750px;font-family:Arial" class="dr-signature-table-main"><tbody><tr> <td colspan="2" style="font-family:Roboto,sans-serif;font-size:11pt;padding-bottom:5px;color:#333">Thanks &amp; Regards,</td> </tr><tr> <td style="width:23%;display:table-cell;vertical-align:middle"><a href="https://www.tech9logy.com" style="display:block;width:100%"><img src="https://tech9logy.com/wp-content/uploads/2023/10/updated_2023-black.png" alt="t9l-logo" style="max-width:100%"></a></td> <td style="width:60%;display:table-cell"> <ul style="list-style:none;margin:0;padding-left:10px"> <li style="font-family:Roboto,sans-serif;font-size:14pt;font-weight:500;color:#333">Labham Vishwakarma</li> <li style="font-size:10pt;color:#333;font-family:Roboto,sans-serif">Associate  eCommerce Developer |<span> <b>ECommerce Development</b></span></li> <li style="font-size:10pt;color:#333;text-decoration:none;font-family:Roboto,sans-serif"><span style="font-size:10pt;color:#333"><span style="color:#00a0dc">p</span>: 6394171918</span></li> <li style="font-family:Roboto,sans-serif"><span style="font-size:10pt;color:#333;font-family:Roboto,sans-serif"><span style="color:#00a0dc">s</span>kype: tech9logy </span></li> <li style="font-size:10pt;color:#333;text-decoration:none;font-family:Roboto,sans-serif"><span style="font-size:10pt;color:#333"><span style="color:#00a0dc">a</span>: 5K-114,1st Floor, N.I.T - 5, Faridabad, Haryana 121001, India</span></li> <li> <span style="font-size:10pt;color:#333;font-family:Roboto,sans-serif"><span style="color:#00a0dc">w: </span><a href="https://www.tech9logy.com/" style="font-size:10pt;color:#333;height:10pt;text-decoration:none;font-family:Roboto,sans-serif">www.tech9logy.com</a></span></li> <li> <span><a href="https://www.facebook.com/Tech9logyCreators"><img src="https://tech9logy.com/wp-content/themes/twentythirteen-child/img/facebook-icon.png" style="vertical-align:middle"></a> <a href="https://www.linkedin.com/company/tech9logy-creators"><img src="https://tech9logy.com/wp-content/themes/twentythirteen-child/img/linkedin-icon.png" style="vertical-align:middle"></a></span> </li> </ul> </td> </tr><tr> <td colspan="2" style="padding-top:10px"><img src="https://www.tech9logy.com/wp-content/uploads/2023/01/signature-strip.jpg"></td></tr></tbody></table></div>';
            $content .= $signature;
            $part = new Part($content);
            $part->setType(Mime::TYPE_HTML);
            $messageBody = new MessageBody();
            $messageBody->addPart($part);
            $message->setFrom($fromEmail);
            $message->addTo($toEmail);
            $message->setSubject(__('TEST EMAIL from Tech9logy SMTP Extension'));
            $message->setBody($messageBody);
            try {
                $transport->send($message);
                $result = [
                    'success' => 1,
                    'message' => 'Mail sent successfully on ' . $toEmail . '. Please check your Mailbox.'
                ];
                return $this->getResponse()->representJson(
                    $this->jsonHelper->jsonEncode($result)
                );
            } catch (\Exception $e) {
                $result = [
                    'success' => 0,
                    'message' => $e->getMessage()
                ];
                return $this->getResponse()->representJson(
                    $this->jsonHelper->jsonEncode($result)
                );
            }
        }
    }
}
