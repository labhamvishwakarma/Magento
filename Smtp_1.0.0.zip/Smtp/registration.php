<?php
/**
 * @author    Labham Vishwakarma
 * @copyright Copyright (c) 2023 Tech9logy (https://www.tech9logy.com/)
 * @package   Tech9logy_Smtp
 */
\Magento\Framework\Component\ComponentRegistrar::register(
    \Magento\Framework\Component\ComponentRegistrar::MODULE,
    'Tech9logy_Smtp',
    __DIR__
);
