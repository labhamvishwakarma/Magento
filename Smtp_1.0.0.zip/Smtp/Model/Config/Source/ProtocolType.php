<?php
/**
 * @author    Labham Vishwakarma
 * @copyright Copyright (c) 2023 Tech9logy (https://www.tech9logy.com/)
 * @package   Tech9logy_Smtp
 */
namespace Tech9logy\Smtp\Model\Config\Source;

class ProtocolType implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * {@inheritdoc}
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'none', 'label' => 'NONE'],
            ['value' => 'ssl', 'label' => 'SSL'],
            ['value' => 'tls', 'label' => 'TLS']
        ];
    }
}
